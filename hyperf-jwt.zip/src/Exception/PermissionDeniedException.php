<?php
/**
 * Created by PhpStorm.
 * User: liyuzhao
 * Date: 2019-08-01
 * Time: 13:43
 */

namespace ShiSuKj\JwtAuth\Exception;

class PermissionDeniedException extends \RuntimeException
{

}
