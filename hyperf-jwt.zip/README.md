# component-creater

```
composer create-project hyperf/component-creater
```
